export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { prompt } = req.body;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 100
      })
    });

    const data = await response.json();
    return res.status(200).json({ message: data.choices[0].message.content });
  } catch (error) {
    return res.status(500).json({ error: "Failed to fetch from OpenAI" });
  }
}